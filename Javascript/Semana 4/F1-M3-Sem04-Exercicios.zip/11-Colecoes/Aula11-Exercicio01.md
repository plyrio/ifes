
### EXERCÍCIOS (AULA 11 - COLEÇÕES)
<hr>

1.	Leia 8 números inteiros do usuário e armazene-os em uma coleção indexada (array). Depois, calcula à média desses valores. Ao final, exiba todos os números do array maiores que à média calculada.
<br>

| Entrada                           | Saída       | 
|-----------------------------------|-------------|
|array = [9, 4, 3, 7, 10, 6, 8, 5]  |9  7  10  8  |
