
### EXERCÍCIOS (AULA 11 - COLEÇÕES)
<hr>

2.	Dadas duas sequências com 4 números inteiros entre 0 e 9, calcular a sequência de números que representa a soma das sequências anteriores.
<br>

| Entrada                    | Saída          | 
|----------------------------|----------------|
|array1 = [1, 2, 3, 4] <br> array2 = [5, 6, 7, 8] |[6, 8, 10, 12]  |
