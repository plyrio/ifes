
### EXERCÍCIOS (AULA 10 - COMANDOS DE REPETIÇÃO ANINHADOS)
<hr>

2. Escreva um programa que mostre na tela os 3 primeiros números perfeitos. Um número perfeito é aquele que é igual à soma dos seus divisores.
<br>

   **Exemplos de números perfeitos:**
<br>
   6 = 1+2+3
   
   28= 1+2+4+7+14
