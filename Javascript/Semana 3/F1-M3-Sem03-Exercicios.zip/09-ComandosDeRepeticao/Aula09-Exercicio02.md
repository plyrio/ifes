
### EXERCÍCIOS (AULA 09 - COMANDOS DE REPETIÇÃO)
<hr>

2.	Faça um algoritmo que conte de 1 a 100 e a cada múltiplo de 10 emita uma mensagem: “Múltiplo de 10: <número>”.

Na figura a seguir temos uma parte da exibição do resultado (neste caso, considerrando o intervalo de 1 até 20):

![Aula09-Ex02](Aula09-Exercicio02.png)