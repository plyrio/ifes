// Implementar comando de repetição (de 1 até 20)

// Implementar os comandos de decisão para verificar números quadrados pares ou ímpares