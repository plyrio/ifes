### EXERCÍCIOS (AULA 04 - SINTAXE E TIPO DE DADOS)
<hr>
1. Na finalidade de conhecer melhor os tipos de variáveis existentes no JavaScript, atribuir valores a elas, e mostrar na tela estes valores, construa o seguinte algoritmo:

```
idade = 20;
altura = 1.75;
nome = "José";
pagou = true;

console.log("Os valores atribuídos as variáveis são: ");
console.log("Idade: ", idade);
console.log("Altura: ", altura);
console.log("Nome: ", nome);
console.log("Pagou: ", pagou);

console.log("Os tipos das variáveis são: ");
console.log("idade ", typeof (idade));
console.log("altura ", typeof (altura));
console.log("nome ", typeof (nome));
console.log("pagou ", typeof (pagou));
```