
### EXERCÍCIOS (AULA 09 - COMANDOS DE REPETIÇÃO)
<hr>

4.	Faça um algoritmo que determine o maior entre N números inteiros positivos. A condição de parada é a entrada de um valor 0, ou seja, o algoritmo deve ficar calculando o maior até que a entrada seja igual a 0 (ZERO).