for (let i = 7; i <= 100; i++) {
  if (i % 10 == 0) {
    console.log("Múltiplo de 10: ", i);
  } else {
    console.log(i);
  }
}