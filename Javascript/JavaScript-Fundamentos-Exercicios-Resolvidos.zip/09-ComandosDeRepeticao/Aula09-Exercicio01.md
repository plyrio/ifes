
### EXERCÍCIOS (AULA 09 - COMANDOS DE REPETIÇÃO)
<hr>

1. Desenvolva um programa imprime na tela os números entre 7 e 1000 que tem resto 3 quando divididos por 7.