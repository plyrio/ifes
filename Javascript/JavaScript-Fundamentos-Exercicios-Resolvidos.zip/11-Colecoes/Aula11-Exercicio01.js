const prompt = require("prompt-sync")();

var array = [];
var soma = 0;

for (let i = 0; i < 8; i++) {
  let num = parseInt(prompt('Digite um número: '));
  soma = soma + num;
  array.push(num);
}

var media = soma / 8;

for (let i = 0; i < 8; i++) {
  if (array[i] > media) {
    console.log(array[i]);
  }
}