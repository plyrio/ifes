
### EXERCÍCIOS (AULA 11 - COLEÇÕES)
<hr>

3. Escreva um algoritmo que calcule a interseção (valores em comum) entre os valores contidos em dois arrays de 5 elementos, array1 e array2 (lidos pelo teclado) e armazene estes valores no array3, mostrando-os no final.
<br>

| Entrada                    | Saída          | 
|----------------------------|----------------|
|array1 = [1, 14, 2, 4, 7] <br> array2 = [5, 6, 1, 2, 10] |[1, 2]  |
