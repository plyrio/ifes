console.log("REPL COM EXERCÍCIOS RESOLVIDOS");
console.log("04 - Variáveis");
console.log("05 - Operadores");
console.log("06 - Entrada de Dados");
console.log("07 - Comandos de Decisão");
console.log("08 - Comandos de Decisão Aninhados");
console.log("09 - Comandos de Repetição");
console.log("10 - Comandos de Repetição Aninhados");
console.log("11 - Coleções Indexadas (Arrays)");
console.log("12 - Funções");

console.log("\nInstruções para executar os códigos:");
console.log("- Clique na opção 'Fork Repl'");
console.log("- Abra a aba do 'Shell' no Repl");
console.log("- Entre na pasta: 'cd <nome da pasta>'");
console.log("- Execute: 'node <nome do arquivo>'");

console.log("\nExemplo:");
console.log("cd 04-Variaveis");
console.log("node Aula04-Exercicio01");
