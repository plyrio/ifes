

### EXERCÍCIOS (AULA 08 - COMANDOS DE DECISÃO ANINHADOS)
<hr>

2. Crie um algoritmo, utilizando a linguagem JavaScript, que receba pelo teclado os valores dos três ângulos internos de um triângulo. Depois verifique se é triângulo, de acordo com a Propriedade.

   Caso não seja triângulo mostre uma mensagem “Não é triângulo!”.
   Caso seja triângulo, mostre a classificação do triângulo quanto aos ângulos:
      *	"Acutângulo" (três ângulos agudos);
      *	"Retângulo" (um ângulo reto);
      *	"Obtusângulo" (um ângulo obtuso);

   <br>
   
   **Propriedades:**
   
   *	A soma dos ângulos de um triângulo deve ser igual a 180 graus
   *	Ângulo agudo: menor do que 90 graus
   *	Ângulo reto: exatamente 90 graus
   *	Ângulo obtuso: maior que 90 graus e menor que 180 graus

![Triângulos](Aula08-Exercicio02.png)