Atividade Prática da 2ª semana (Repl.it)
Olá!

Nesta atividade você vai colocar em prática o conteúdo abordado na semana.

ESTA ATIVIDADE SERÁ DESENVOLVIDA NO REPL.IT E DEVERÁ SER POSTADA NESTA TAREFA EM ARQUIVO ZIP, CONFORME ORIENTAÇÕES ABAIXO:

Você deve criar um Servidor Web em Node que ofereça o serviço de venda (site) de produtos pela internet (com URL), com as seguintes funcionalidades:

Crie uma página principal (que será lida) em HTML com título e subtítulo. Apresente sua empresa, o negócio da empresa e seus produtos (pelo menos 2 parágrafos por produto).
Adicione CSS à página, mude a cor de fundo e a cor da fonte, pelo menos.
Faça a leitura desse arquivo (HTML).
Crie pelo menos 3 páginas com a descrição dos produtos (pelo menos 1 parágrafo por produto) (que será lida) em HTML com título e subtítulo. 
Adicione CSS à página, mude a cor de fundo e a cor da fonte, pelo menos.
Faça a leitura desses arquivos (HTML).
Siga o caminho abaixo:

Assista aos vídeos da semana.
Leia, em paralelo, os materiais das aulas da semana.
Acesse o Replit.
Realize a codificação da atividade (Prática da semana 2).
Salve o código no seu computador.
Compacte o arquivo.
Envie o arquivo aqui.
Se a atividade não estiver sendo mostrada para você, entre em contato com o monitor ou professor mediador o quanto antes. 

Valor: 5 pontos

Prazo final: 10/04/2023