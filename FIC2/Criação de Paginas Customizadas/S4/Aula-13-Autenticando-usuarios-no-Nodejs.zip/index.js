const express = require('express');
const app = express();
const bodyParse = require('body-parser');
const path = require('path');
const session = require('express-session');
const porta = 443;

app.use(session({secret: '1234567890'}));
app.use(bodyParse.urlencoded({extended: false}));

var login = 'admin';
var pass = '1234';

app.engine('html', require('ejs').renderFile);
app.set('view engine', 'html');
app.set('views', path.join(__dirname, './'));

app.get('/', (req, res) => {
  if (req.session.login){
    res.render('logado');
    console.log("Usuário logado: " + req.session.login);
  }  else {
    res.render('home');
  }
});

app.post('/', (req, res) => {
  if (req.body.password == pass && req.body.login == login){
    req.session.login = login;
    res.render('logado');
  } else {
    res.render('home');
  }
});

app.listen(porta, () => {
  console.log('Servidor rodando na porta ' + porta);
});