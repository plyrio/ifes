const express = require("express");
const app = express();
const porta = 443;
const nodemailer = require("nodemailer");

app.get("/", (req, res) => {
  res.send("Enviando e-mail com o Nodemailer!");
});

app.get("/sendemail", async (req, res) => {
  var transport = nodemailer.createTransport({
    host: "sandbox.smtp.mailtrap.io",
    port: 2525,
    auth: {
      user: "3f9d8414929670",
      pass: "374111c71a93c2",
    },
  });
  var message = {
    from: "pedrolyrio@ucl.br",
    to: "aula12@ifes.br",
    subject: "Teste de e-mail",
    text: "Este é um teste de e-mail enviado usando o Nodemailer!",
    html: "<p>Este é um teste de e-mail enviado usando o Nodemailer!</p>",
  };
  transport.sendMail(message, (err) => {
    if (err)
      return res.status(400).json({
        erro: true,
        mensagem: "Erro: E-mail não enviado!",
      });
    else
      return res.json({
        erro: false,
        mensagem: "E-mail enviado com sucesso!",
      });
  });
});

app.listen(porta, () => {
  console.log("Servidor rodando!");
});
