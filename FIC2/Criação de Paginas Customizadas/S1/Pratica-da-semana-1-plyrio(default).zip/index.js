const http = require('http');
const fs = require('fs');
const porta = 443;

const servidor = http.createServer((req, res) => {
  fs.readFile('index.html', (err, arquivo) => {
    res.writeHead(200, { 'Content-type': 'text/html' });
    res.write(arquivo);
    return res.end();
  });
  fs.appendFile('arqivo.txt', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry', (err) => {
    if (err) throw err;
    console.log(`Arquivo criado com sucesso!`);
    res.end();
  });
});
servidor.listen(porta, () => {
  console.log(`Servidor rodando na porta ${porta}`);
});