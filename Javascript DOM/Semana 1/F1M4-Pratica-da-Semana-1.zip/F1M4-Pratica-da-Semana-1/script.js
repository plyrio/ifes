// Selecionar todos elementos da classe 'produto_preco'

// Implementar um comando de repetição para analisar o valor 'innerText' de cada um dos elementos e somá-los (lembre-se de converter o valor para float)

// Escrever no conteúdo da página o valor da soma 

